# build.sh (auto-generated)
