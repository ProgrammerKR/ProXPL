# security_model.md (auto-generated)
